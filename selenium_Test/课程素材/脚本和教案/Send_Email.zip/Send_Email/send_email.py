import  smtplib
from email.mime.text import MIMEText
from email.header import Header

smtpserver='smtp.163.com'

user='yuexiaolu2015@163.com'
password='...'

sender='yuexiaolu2015@163.com'
receive='yuexiaolu2015@126.com'

subject='Web Selenium 自动化测试报告'
content='<html><h1 style="color:red">我要自学网，自学成才！</h1></html>'

msg=MIMEText(content,'html','utf-8')
msg['Subject']=Header(subject,'utf-8')
msg['From']='yuexiaolu2015@163.com'
msg['To']='yuexiaolu2015@126.com'

smtp=smtplib.SMTP_SSL(smtpserver,465)
smtp.helo(smtpserver)
smtp.ehlo(smtpserver)
smtp.login(user,password)

print("Start send Email...")
smtp.sendmail(sender,receive,msg.as_string())
smtp.quit()
print("Send Email end!")

